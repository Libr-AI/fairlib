Both `classifier.py` and `debias.py` are copied from the INLP projection repo. 
See https://github.com/shauli-ravfogel/nullspace_projection/tree/master/src for more details.